// Verifies that router.js reproduces scikit-learn's probabilities.
// Run:  node demo/check_parity.js
const fs = require("fs");
const path = require("path");
const { Router } = require("./router.js");

const m = JSON.parse(fs.readFileSync(path.join(__dirname, "model.json")));
const fx = JSON.parse(fs.readFileSync(path.join(__dirname, "parity_fixtures.json")));
const r = new Router(m);
let maxDiff = 0, sameTop = 0;
fx.texts.forEach((t, i) => {
  const p = r.route(t).probs;
  p.forEach((v, k) => (maxDiff = Math.max(maxDiff, Math.abs(v - fx.probs[i][k]))));
  const pyTop = fx.probs[i].indexOf(Math.max(...fx.probs[i]));
  if (pyTop === r.route(t).top) sameTop++;
});
console.log(`notes: ${fx.texts.length}  same top-1: ${sameTop}  max |p_js - p_sklearn|: ${maxDiff.toFixed(4)}`);
process.exit(maxDiff < 0.01 && sameTop === fx.texts.length ? 0 : 1);
