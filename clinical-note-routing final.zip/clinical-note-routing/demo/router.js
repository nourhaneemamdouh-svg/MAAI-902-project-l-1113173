// Browser/Node port of the scikit-learn TF-IDF + one-vs-rest logistic
// regression model. Mirrors sklearn exactly:
//   clean_text -> token_pattern \b\w\w+\b -> stop-word filter -> vocabulary
//   -> sublinear tf (1 + ln tf) x idf -> L2 normalise -> sigmoid(w.x + b)
(function (root) {
  function cleanText(t) {
    return String(t).toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  }

  function Router(m) {
    this.m = m;
    this.index = new Map(m.vocab.map((w, i) => [w, i]));
    this.stop = new Set(m.stop_words);
  }

  // Sparse TF-IDF vector as Map(featureIndex -> value)
  Router.prototype.vectorise = function (text) {
    const toks = cleanText(text).match(/\b\w\w+\b/g) || [];
    const tf = new Map();
    for (const t of toks) {
      if (this.stop.has(t)) continue;
      const j = this.index.get(t);
      if (j !== undefined) tf.set(j, (tf.get(j) || 0) + 1);
    }
    let norm = 0;
    for (const [j, c] of tf) {
      const v = (1 + Math.log(c)) * this.m.idf[j];
      tf.set(j, v); norm += v * v;
    }
    norm = Math.sqrt(norm) || 1;
    for (const [j, v] of tf) tf.set(j, v / norm);
    return tf;
  };

  Router.prototype.route = function (text, tau) {
    const m = this.m, x = this.vectorise(text);
    const probs = m.labels.map((_, k) => {
      let z = m.b[k];
      for (const [j, v] of x) z += m.W[k][j] * v;
      return 1 / (1 + Math.exp(-z));
    });
    const order = probs.map((p, k) => k).sort((a, b) => probs[b] - probs[a]);
    const top = order[0];
    const assigned = order.filter((k) => probs[k] >= m.threshold);
    if (!assigned.includes(top)) assigned.unshift(top);
    // evidence: words that pushed the top specialty up (tf-idf x weight)
    const evidence = [...x].map(([j, v]) => [m.vocab[j], v * m.W[top][j]])
      .filter((e) => e[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 8);
    return {
      probs, order, top, assigned, evidence, confidence: probs[top],
      decision: probs[top] >= (tau ?? m.tau) ? "auto" : "review",
      nTokens: x.size,
    };
  };

  root.Router = Router;
  root.cleanText = cleanText;
  if (typeof module !== "undefined") module.exports = { Router, cleanText };
})(typeof window !== "undefined" ? window : globalThis);
