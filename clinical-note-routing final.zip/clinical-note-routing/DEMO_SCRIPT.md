# Demonstration script (about 4 minutes)

Record your screen with the browser demo (`demo/index.html`, or the published link) and the notebook open in two tabs.

| Time | Show | Say |
|---|---|---|
| 0:00–0:30 | Title of the demo page | "Clinical notes must reach the right specialty before they can support referral, coding or audit. This prototype routes a transcription to its specialties, says how sure it is, and sends uncertain notes to a person." |
| 0:30–1:15 | Notebook, section 1 output (`keywords` 100%, 1,823 of 3,813) and Figure 3 | "Auditing the data changed the design. The keywords column contains the answer, so I never use it. The 3,813 rows are only 1,821 unique notes, most filed under several specialties, so this is a multi-label problem and I split on unique notes." |
| 1:15–2:00 | Notebook, model table and Figure 5 | "With leakage-free 5-fold cross-validation, logistic regression on TF-IDF reaches macro-F1 0.81 and puts the right specialty first for 93% of notes, ahead of Naive Bayes and SVM." |
| 2:00–3:00 | Demo: click *Lumbar spine CT*, then *Psychiatric discharge*, then paste a short cardiology note | "It assigns Radiology, Orthopedic and Neurology, matching the source labels. The highlighted words show why. For my own cardiology text it picks Cardiovascular and highlights echocardiogram and mitral." |
| 3:00–3:30 | Demo: drag the review threshold to 0.95 on a borderline note | "Below the threshold, the note goes to a person. Confidence is calibrated, so at 0.7 the system routes 88% of notes automatically at 97% accuracy." |
| 3:30–4:00 | Notebook, ablation table | "Finally, the same model scores 0.10 or 0.81 accuracy depending only on the evaluation protocol. That is why published results disagree, and why I report a leakage-free number. The design runs locally, so no patient text leaves the device." |

Tip: paste this note in the demo to show free-text input:

> HISTORY: 67-year-old male with progressive shortness of breath and chest tightness on exertion. ECHOCARDIOGRAM: ejection fraction 35%, moderate mitral regurgitation, left ventricular hypertrophy. PLAN: start beta blocker, cardiology follow-up, consider cardiac catheterization.
