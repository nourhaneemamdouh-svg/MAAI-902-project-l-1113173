"""
Clinical named-entity recognition: diseases, drugs (and procedures) in a note.

Two interchangeable back-ends; the first one that loads is used.

1. scispaCy `en_ner_bc5cdr_md` (Neumann et al., 2019) -> DISEASE, CHEMICAL
       pip install --no-deps https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_ner_bc5cdr_md-0.5.4.tar.gz
   (--no-deps stops pip from downgrading spaCy; the model was built for spaCy 3.7
   and may not load on newer spaCy / Python 3.13.)

2. Hugging Face `d4data/biomedical-ner-all` (DistilBERT trained on the
   MACCROBAT case-report corpus) -> used automatically if (1) is unavailable.
       pip install transformers
   Its labels are mapped onto the same output keys:
       Disease_disorder, Sign_symptom          -> DISEASE
       Medication                               -> CHEMICAL
       Diagnostic_ / Therapeutic_procedure      -> PROCEDURE

Pass the ORIGINAL transcription (with punctuation and case), not the cleaned
model input: NER relies on sentence structure.

Run:  python src/ner.py            (prints entities for 3 sample notes)
"""
from __future__ import annotations

from collections import Counter
from functools import lru_cache

SCISPACY_MODEL = "en_ner_bc5cdr_md"
HF_MODEL = "d4data/biomedical-ner-all"
HF_MAP = {"Disease_disorder": "DISEASE", "Sign_symptom": "DISEASE", "Medication": "CHEMICAL",
          "Diagnostic_procedure": "PROCEDURE", "Therapeutic_procedure": "PROCEDURE"}
KEYS = ("DISEASE", "CHEMICAL", "PROCEDURE")


@lru_cache(maxsize=1)
def _load():
    """Return (backend_name, model). Tries scispaCy, then Hugging Face."""
    errors = []
    try:
        import spacy
        nlp = spacy.load(SCISPACY_MODEL)
        nlp("Patient on aspirin for hypertension.")  # smoke test: fails fast if incompatible
        return "scispacy", nlp
    except Exception as e:  # noqa: BLE001
        errors.append(f"scispaCy: {type(e).__name__}: {str(e)[:120]}")
    try:
        from transformers import pipeline
        return "huggingface", pipeline("token-classification", model=HF_MODEL,
                                       aggregation_strategy="simple")
    except Exception as e:  # noqa: BLE001
        errors.append(f"Hugging Face: {type(e).__name__}: {str(e)[:120]}")
    raise RuntimeError("No NER back-end could be loaded.\n" + "\n".join(errors))


def backend() -> str:
    return _load()[0]


def _chunks(text: str, words: int = 180):
    """Split long notes so each piece fits the transformer's 512-token window."""
    toks = text.split()
    for i in range(0, len(toks), words):
        yield " ".join(toks[i:i + words])


def extract_entities(text: str, top: int = 10) -> dict[str, list[tuple[str, int]]]:
    """Most frequent entities per type, lower-cased and counted, e.g.
    {"DISEASE": [("hypertension", 3), ...], "CHEMICAL": [...], "PROCEDURE": [...]}."""
    name, model = _load()
    found: dict[str, Counter] = {k: Counter() for k in KEYS}
    if name == "scispacy":
        for e in model(text[:100_000]).ents:
            if e.label_ in found:
                found[e.label_][e.text.lower()] += 1
    else:
        for piece in _chunks(text):
            for e in model(piece):
                key = HF_MAP.get(e["entity_group"])
                word = e["word"].replace(" ##", "").replace("##", "").strip().lower()
                if key and len(word) > 2 and e["score"] >= 0.5:
                    found[key][word] += 1
    return {k: c.most_common(top) for k, c in found.items()}


if __name__ == "__main__":
    import pandas as pd
    import config as C
    raw = pd.read_csv(C.DATA_RAW)
    print("Back-end:", backend())
    for _, r in raw.sample(3, random_state=C.SEED).iterrows():
        print("\nLabel:", r["medical_specialty"].strip())
        print(extract_entities(r["transcription"]))
