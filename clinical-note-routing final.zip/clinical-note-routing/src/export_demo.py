"""
Export the trained TF-IDF + logistic-regression model to JSON so the web demo
(demo/index.html) can run it entirely in the browser -- no server, and no
clinical text ever leaves the user's machine (a privacy-by-design choice).

The JSON holds: vocabulary, IDF weights, one coefficient vector per specialty,
intercepts, the decision threshold, the stop-word list, headline metrics and a
few sample notes. demo/check_parity.js verifies that the browser maths gives the
same probabilities as scikit-learn.

Run:  python src/export_demo.py
"""
import json

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

import re

import config as C
from data_prep import clean_text
from predict import REVIEW_TAU, load


def tidy(t: str) -> str:
    """Undo MTSamples' flattened formatting: '.,' marks a line break and
    'HEADER: ,' an empty field separator."""
    t = re.sub(r"\.\s*,", ".\n", str(t))
    t = re.sub(r":\s*,", ":", t)
    t = re.sub(r"\s+,\s*", " ", t)
    return re.sub(r"[ \t]+", " ", t).strip()

# specialty to sample from -> short title shown on the demo button
SAMPLE_PER_LABEL = {
    "Orthopedic": "Lumbar spine CT",
    "Cardiovascular / Pulmonary": "Cardiac stress test",
    "Gastroenterology": "Screening colonoscopy",
    "Neurology": "Head CT, arm numbness",
    "Urology": "Paediatric urethral repair",
    "Psychiatry / Psychology": "Psychiatric discharge",
    "Ophthalmology": "Eyelid surgery",
    "Obstetrics / Gynecology": "Gynaecology discharge",
}


def main():
    b = load()
    model, labels, thr = b["model"], b["labels"], b["threshold"]
    vec = model.named_steps["tfidf"]
    vocab = vec.get_feature_names_out().tolist()
    W = np.vstack([e.coef_[0] for e in model.named_steps["clf"].estimators_])
    bias = [float(e.intercept_[0]) for e in model.named_steps["clf"].estimators_]

    # sample notes: one mid-length note per showcase specialty, shown in its
    # original (readable) form rather than the cleaned model input
    notes = pd.read_pickle(C.DATA_CLEAN)
    raw = pd.read_csv(C.DATA_RAW)
    original = dict(zip(raw["transcription"].map(clean_text), raw["transcription"]))
    samples = []
    for lab, title in SAMPLE_PER_LABEL.items():
        cand = notes[notes["labels"].map(lambda ls: lab in ls) & notes["n_words"].between(80, 450)]
        r = cand.sample(1, random_state=C.SEED).iloc[0]
        samples.append({"title": title, "labels": r["labels"], "text": tidy(original[r["text"]])})

    cv = json.load(open(C.RESULTS / "cv_results.json"))["models"]["TF-IDF + LR (tuned)"]
    out = {
        "labels": labels,
        "vocab": vocab,
        "idf": np.round(vec.idf_, 4).tolist(),
        "W": np.round(W, 3).tolist(),
        "b": np.round(bias, 4).tolist(),
        "threshold": round(float(thr), 4),
        "tau": REVIEW_TAU,
        "stop_words": sorted(ENGLISH_STOP_WORDS),
        "metrics": {k: v[0] for k, v in cv.items()},
        "samples": samples,
    }
    C.DEMO.mkdir(exist_ok=True)
    with open(C.DEMO / "model.json", "w") as f:
        json.dump(out, f, separators=(",", ":"))
    # parity fixtures: sklearn probabilities for 25 notes
    fx = notes.sample(25, random_state=1)
    probs = np.vstack([e.predict_proba(vec.transform(fx["text"]))[:, 1]
                       for e in model.named_steps["clf"].estimators_]).T
    json.dump({"texts": fx["text"].tolist(), "probs": probs.round(6).tolist()},
              open(C.DEMO / "parity_fixtures.json", "w"))
    print("vocab", len(vocab), "labels", len(labels), "-> demo/model.json")


if __name__ == "__main__":
    main()
