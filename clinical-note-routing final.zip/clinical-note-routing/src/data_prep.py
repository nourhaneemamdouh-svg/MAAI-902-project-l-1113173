"""
Data preparation: raw MTSamples-derived CSV  ->  clean, de-duplicated,
multi-label dataset.

Why this step matters
---------------------
The raw file has 3,813 rows but only ~1,823 unique transcriptions: MTSamples
cross-lists the same note under several specialties (e.g. a knee arthroscopy
appears under both "Orthopedic" and "Surgery"). If the rows are split at random,
the *same text* lands in train and test, which inflates scores. We therefore

1. normalise and de-duplicate the transcriptions,
2. merge every label a note was filed under into a label *set* (multi-label),
3. drop document-type labels and very rare specialties,
4. drop near-empty notes,
5. split folds on the unique notes with iterative stratification.

Run:  python src/data_prep.py
"""
from __future__ import annotations

import json
import re
from collections import Counter

import numpy as np
import pandas as pd

import config as C


# --------------------------------------------------------------------------- #
# Text cleaning
# --------------------------------------------------------------------------- #
def clean_text(text: str) -> str:
    """Light, model-agnostic cleaning.

    * lower-case
    * MTSamples encodes line breaks as ",." / ", ," artefacts -> spaces
    * keep letters, digits and spaces only
    * collapse whitespace

    Stop-words are NOT removed here: the TF-IDF vectoriser handles them, and
    transformer models need the full sentence.
    """
    text = str(text).lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# --------------------------------------------------------------------------- #
# Dataset construction
# --------------------------------------------------------------------------- #
def load_raw() -> pd.DataFrame:
    df = pd.read_csv(C.DATA_RAW)
    df["medical_specialty"] = df["medical_specialty"].str.strip()
    return df


def build_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Return (notes, stats). `notes` has one row per unique transcription."""
    stats: dict = {"raw_rows": len(df), "raw_labels": df["medical_specialty"].nunique()}

    # Leakage audit: how often does `keywords` start with the label itself?
    kw_leak = df.apply(
        lambda r: str(r["keywords"]).strip().lower().startswith(r["medical_specialty"].lower()),
        axis=1,
    ).mean()
    stats["keywords_start_with_label_pct"] = round(100 * kw_leak, 1)

    # 1) normalise + de-duplicate on the cleaned text
    df = df.copy()
    df["text"] = df["transcription"].map(clean_text)
    grouped = df.groupby("text")["medical_specialty"].agg(lambda s: sorted(set(s)))
    notes = grouped.reset_index().rename(columns={"medical_specialty": "raw_labels"})
    stats["unique_notes"] = len(notes)
    stats["duplicate_rows_removed"] = len(df) - len(notes)
    stats["notes_with_multiple_labels"] = int((notes["raw_labels"].map(len) > 1).sum())
    stats["mean_labels_per_note_raw"] = round(notes["raw_labels"].map(len).mean(), 2)

    # 2) remove document-type labels
    notes["labels"] = notes["raw_labels"].map(
        lambda ls: [l for l in ls if l not in C.DOCUMENT_TYPE_LABELS]
    )

    # 3) remove rare specialties (support counted on unique notes)
    support = Counter(l for ls in notes["labels"] for l in ls)
    keep = sorted(l for l, n in support.items() if n >= C.MIN_LABEL_SUPPORT)
    dropped_rare = sorted(l for l, n in support.items() if n < C.MIN_LABEL_SUPPORT)
    notes["labels"] = notes["labels"].map(lambda ls: [l for l in ls if l in keep])
    stats["document_type_labels_removed"] = sorted(C.DOCUMENT_TYPE_LABELS)
    stats["rare_labels_removed"] = dropped_rare

    # 4) drop notes with no specialty left, or too short to route
    notes["n_words"] = notes["text"].str.split().map(len)
    no_label = notes["labels"].map(len) == 0
    too_short = notes["n_words"] < C.MIN_WORDS
    stats["notes_dropped_no_specialty"] = int(no_label.sum())
    stats["notes_dropped_too_short"] = int((too_short & ~no_label).sum())
    notes = notes[~no_label & ~too_short].reset_index(drop=True)

    stats["final_notes"] = len(notes)
    stats["final_labels"] = keep
    stats["n_final_labels"] = len(keep)
    stats["mean_labels_per_note_final"] = round(notes["labels"].map(len).mean(), 2)
    stats["label_support_final"] = dict(
        sorted(Counter(l for ls in notes["labels"] for l in ls).items(), key=lambda x: -x[1])
    )
    stats["words_median"] = int(notes["n_words"].median())
    stats["words_p90"] = int(notes["n_words"].quantile(0.9))
    stats["words_max"] = int(notes["n_words"].max())
    return notes, stats


def to_matrix(notes: pd.DataFrame, labels: list[str]) -> np.ndarray:
    """Binary indicator matrix Y (n_notes x n_labels)."""
    idx = {l: i for i, l in enumerate(labels)}
    Y = np.zeros((len(notes), len(labels)), dtype=int)
    for r, ls in enumerate(notes["labels"]):
        for l in ls:
            Y[r, idx[l]] = 1
    return Y


# --------------------------------------------------------------------------- #
# Iterative stratification (Sechidis, Tsoumakas & Vlahavas, 2011)
# --------------------------------------------------------------------------- #
def iterative_stratified_folds(Y: np.ndarray, n_folds: int = 5, seed: int = 42) -> np.ndarray:
    """Assign each note to a fold so every label is spread evenly.

    Plain stratified K-fold only works for single-label data. This greedy
    algorithm repeatedly takes the rarest remaining label and hands its notes to
    the fold that still "wants" that label most. Returns a fold id per row.
    """
    rng = np.random.default_rng(seed)
    n, k = Y.shape
    fold_of = -np.ones(n, dtype=int)
    # desired number of notes / label occurrences per fold
    want_total = np.full(n_folds, n / n_folds)
    want_label = np.tile(Y.sum(0) / n_folds, (n_folds, 1)).astype(float)
    remaining = np.ones(n, dtype=bool)

    while remaining.any():
        counts = Y[remaining].sum(0).astype(float)
        if counts.sum() == 0:  # notes without labels (not expected here)
            for i in np.where(remaining)[0]:
                f = int(np.argmax(want_total)); fold_of[i] = f; want_total[f] -= 1
            break
        counts[counts == 0] = np.inf
        lab = int(np.argmin(counts))                    # rarest label left
        rows = np.where(remaining & (Y[:, lab] == 1))[0]
        rng.shuffle(rows)
        for i in rows:
            cand = np.flatnonzero(want_label[:, lab] == want_label[:, lab].max())
            if len(cand) > 1:  # tie-break on total demand, then randomly
                cand = cand[want_total[cand] == want_total[cand].max()]
            f = int(rng.choice(cand))
            fold_of[i] = f
            remaining[i] = False
            want_label[f] -= Y[i]
            want_total[f] -= 1
    return fold_of


def main() -> None:
    df = load_raw()
    notes, stats = build_dataset(df)
    Y = to_matrix(notes, stats["final_labels"])
    notes["fold"] = iterative_stratified_folds(Y, C.N_FOLDS, C.SEED)

    C.RESULTS.mkdir(parents=True, exist_ok=True)
    notes.to_pickle(C.DATA_CLEAN)
    with open(C.RESULTS / "data_stats.json", "w") as f:
        json.dump(stats, f, indent=2)

    print(json.dumps({k: v for k, v in stats.items() if k != "label_support_final"}, indent=2))
    print("\nNotes per fold:", np.bincount(notes["fold"]))


if __name__ == "__main__":
    main()
