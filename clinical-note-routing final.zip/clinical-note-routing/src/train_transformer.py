"""
Fine-tune a domain-adapted transformer for multi-label specialty routing.

>>> Run on a GPU (Google Colab T4 is enough). Not needed for the demo. <<<

Uses the SAME unique-note folds, threshold rule and metrics as the classical
models (train_baseline.py), so results are directly comparable.

Long notes: 45% of notes exceed BERT's 512-token window. Each note is split
into overlapping 512-token chunks (stride 128). Every chunk inherits the note's
labels for training; at prediction time the chunk probabilities are averaged
back into one probability vector per note.

Examples
--------
    # Bio_ClinicalBERT (Alsentzer et al., 2019), fold 0 only (~10 min on a T4)
    python src/train_transformer.py --model emilyalsentzer/Bio_ClinicalBERT

    # Long-context alternative (Li et al., 2023): 4,096 tokens, no chunking needed
    python src/train_transformer.py --model yikuan8/Clinical-Longformer --max-len 4096 --batch 2

    # All five folds for the final table
    python src/train_transformer.py --model emilyalsentzer/Bio_ClinicalBERT --folds 0 1 2 3 4
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from transformers import (AutoModelForSequenceClassification, AutoTokenizer, Trainer,
                          TrainingArguments, set_seed)

import config as C
from data_prep import to_matrix
from train_baseline import decide, metrics, tune_threshold


# --------------------------------------------------------------------------- #
# Chunked dataset
# --------------------------------------------------------------------------- #
class ChunkedNotes(Dataset):
    """Tokenises notes into overlapping windows and remembers which note each
    window came from (`owner`) so predictions can be pooled per note."""

    def __init__(self, texts, Y, tok, max_len, stride=128):
        enc = tok(list(texts), truncation=True, max_length=max_len, stride=stride,
                  return_overflowing_tokens=True, padding="max_length")
        self.owner = np.array(enc.pop("overflow_to_sample_mapping"))
        self.enc = enc
        self.Y = Y[self.owner].astype(np.float32)

    def __len__(self):
        return len(self.owner)

    def __getitem__(self, i):
        item = {k: torch.tensor(v[i]) for k, v in self.enc.items()}
        item["labels"] = torch.tensor(self.Y[i])
        return item


class WeightedTrainer(Trainer):
    """BCE loss with a per-label positive weight (neg/pos ratio, capped at 20)
    so rare specialties are not ignored -- the transformer analogue of
    class_weight='balanced' in the logistic regression."""

    def __init__(self, pos_weight, **kw):
        super().__init__(**kw)
        self.pos_weight = pos_weight

    def compute_loss(self, model, inputs, return_outputs=False, **kw):
        labels = inputs.pop("labels")
        out = model(**inputs)
        loss_fn = torch.nn.BCEWithLogitsLoss(pos_weight=self.pos_weight.to(out.logits.device))
        loss = loss_fn(out.logits, labels)
        return (loss, out) if return_outputs else loss


def make_training_args(**kw) -> TrainingArguments:
    """Build TrainingArguments on both Transformers 4.x and 5.x: renames
    `eval_strategy` for versions before 4.41 and drops any argument the
    installed version does not accept (printing it, so nothing is silent)."""
    import inspect
    params = inspect.signature(TrainingArguments.__init__).parameters
    if "eval_strategy" not in params and "evaluation_strategy" in params:
        kw["evaluation_strategy"] = kw.pop("eval_strategy")
    dropped = [k for k in kw if k not in params]
    if dropped:
        print("Ignoring arguments not supported by this Transformers version:", dropped)
    return TrainingArguments(**{k: v for k, v in kw.items() if k in params})


def pooled_probs(trainer, ds, n_notes):
    """Average sigmoid probabilities over every chunk of a note."""
    logits = trainer.predict(ds).predictions
    probs = 1 / (1 + np.exp(-logits))
    out = np.zeros((n_notes, probs.shape[1]))
    np.add.at(out, ds.owner, probs)
    return out / np.bincount(ds.owner, minlength=n_notes)[:, None]


# --------------------------------------------------------------------------- #
def run_fold(k, notes, Y, labels, args):
    set_seed(C.SEED)
    tok = AutoTokenizer.from_pretrained(args.model)
    tr_idx = np.where(notes["fold"] != k)[0]
    te_idx = np.where(notes["fold"] == k)[0]
    # inner validation split (15%) for early stopping and threshold tuning
    rng = np.random.default_rng(C.SEED)
    val_idx = rng.choice(tr_idx, int(0.15 * len(tr_idx)), replace=False)
    fit_idx = np.setdiff1d(tr_idx, val_idx)

    X = notes["text"].values
    ds_fit = ChunkedNotes(X[fit_idx], Y[fit_idx], tok, args.max_len)
    ds_val = ChunkedNotes(X[val_idx], Y[val_idx], tok, args.max_len)
    ds_te = ChunkedNotes(X[te_idx], Y[te_idx], tok, args.max_len)

    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, num_labels=len(labels), problem_type="multi_label_classification",
        id2label=dict(enumerate(labels)), label2id={l: i for i, l in enumerate(labels)})

    pos = Y[fit_idx].sum(0)
    pos_weight = torch.tensor(np.minimum((len(fit_idx) - pos) / np.maximum(pos, 1), 20.0),
                              dtype=torch.float32)

    # Warm-up = 10% of all optimiser steps, given as a step count because
    # Transformers v5 removed `warmup_ratio`.
    steps_per_epoch = -(-len(ds_fit) // (args.batch * args.accum))   # ceiling division
    warmup = int(0.1 * steps_per_epoch * args.epochs)
    targs = make_training_args(
        output_dir=str(C.MODELS / f"tmp_fold{k}"), num_train_epochs=args.epochs,
        learning_rate=args.lr, per_device_train_batch_size=args.batch,
        per_device_eval_batch_size=args.batch * 2, gradient_accumulation_steps=args.accum,
        warmup_steps=warmup, weight_decay=0.01, fp16=torch.cuda.is_available(),
        eval_strategy="epoch", save_strategy="epoch", load_best_model_at_end=True,
        metric_for_best_model="eval_loss", save_total_limit=1, report_to="none", seed=C.SEED)

    trainer = WeightedTrainer(pos_weight=pos_weight, model=model, args=targs,
                              train_dataset=ds_fit, eval_dataset=ds_val)
    trainer.train()

    thr = tune_threshold(pooled_probs(trainer, ds_val, len(val_idx)), Y[val_idx])
    S = pooled_probs(trainer, ds_te, len(te_idx))
    res = metrics(Y[te_idx], S, decide(S, thr))
    res["threshold"] = thr
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="emilyalsentzer/Bio_ClinicalBERT")
    ap.add_argument("--max-len", type=int, default=512)
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--accum", type=int, default=2)
    ap.add_argument("--folds", type=int, nargs="+", default=[0])
    args = ap.parse_args()

    notes = pd.read_pickle(C.DATA_CLEAN)
    labels = json.load(open(C.RESULTS / "data_stats.json"))["final_labels"]
    Y = to_matrix(notes, labels)

    rows = []
    for k in args.folds:
        r = run_fold(k, notes, Y, labels, args)
        print(f"fold {k}:", {m: round(v, 3) for m, v in r.items()})
        rows.append(r)
    df = pd.DataFrame(rows)
    summary = {m: [round(df[m].mean(), 3), round(df[m].std(ddof=0), 3)] for m in df}
    tag = args.model.split("/")[-1]
    json.dump({"model": args.model, "folds": args.folds, "summary": summary, "per_fold": rows},
              open(C.RESULTS / f"transformer_{tag}.json", "w"), indent=2)
    print(summary)


if __name__ == "__main__":
    main()
