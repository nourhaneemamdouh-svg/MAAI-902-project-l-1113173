"""
Exploratory data analysis: produces the three figures used in the report.

    fig1_label_counts.png   rows per label in the raw file vs unique notes
    fig2_note_length.png    words per unique note, with the BERT 512-token limit
    fig3_cooccurrence.png   how often specialties share the same note

Run after data_prep.py:  python src/eda.py
"""
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config as C
from data_prep import load_raw, to_matrix

# Reference palette (validated, colour-blind safe) -- see README
BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e6e5e1"

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
    "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 150, "savefig.bbox": "tight", "font.family": "DejaVu Sans",
})

# Rough WordPiece ratio for clinical English (tokens per word). Used only to
# draw an indicative 512-token line on the length histogram.
TOKENS_PER_WORD = 1.3


def fig_label_counts(raw: pd.DataFrame, notes: pd.DataFrame, labels: list[str]) -> None:
    """Support per specialty after cleaning (a note counts once per label)."""
    uniq = pd.Series([l for ls in notes["labels"] for l in ls]).value_counts().sort_values()
    y = np.arange(len(uniq))
    fig, ax = plt.subplots(figsize=(7.5, 6.6))
    ax.barh(y, uniq.values, height=0.7, color=BLUE)
    for yi, v in zip(y, uniq.values):
        ax.text(v + 8, yi, str(v), va="center", fontsize=8, color=INK2)
    ax.set_yticks(y, uniq.index)
    ax.set_xlabel("Unique notes carrying the label")
    ax.grid(axis="x", color=GRID); ax.set_axisbelow(True)
    ratio = uniq.max() / uniq.min()
    ax.set_title(f"Notes per specialty (24 labels, {ratio:.0f}:1 imbalance)", loc="left", color=INK)
    fig.savefig(C.FIGURES / "fig1_label_counts.png"); plt.close(fig)


def fig_note_length(notes: pd.DataFrame) -> None:
    words = notes["n_words"]
    limit = 512 / TOKENS_PER_WORD
    over = (words > limit).mean() * 100
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    ax.hist(words, bins=60, color=BLUE, edgecolor="white", linewidth=0.6)
    ax.axvline(limit, color=INK, linestyle="--", linewidth=1.2)
    ax.text(limit + 20, ax.get_ylim()[1] * 0.9,
            f"≈512 BERT tokens (~{limit:.0f} words)\n{over:.0f}% of notes are longer",
            color=INK, va="top")
    ax.set_xlabel("Words per note"); ax.set_ylabel("Number of notes")
    ax.grid(axis="y", color=GRID); ax.set_axisbelow(True)
    ax.set_title(f"Note length (median {int(words.median())} words)", loc="left", color=INK)
    fig.savefig(C.FIGURES / "fig2_note_length.png"); plt.close(fig)


def fig_cooccurrence(notes: pd.DataFrame, labels: list[str], top: int = 12) -> None:
    Y = to_matrix(notes, labels)
    order = np.argsort(-Y.sum(0))[:top]
    M = (Y[:, order].T @ Y[:, order]).astype(float)
    np.fill_diagonal(M, np.nan)  # diagonal = support, not co-occurrence
    names = [labels[i] for i in order]
    fig, ax = plt.subplots(figsize=(7.5, 6.4))
    im = ax.imshow(M, cmap="Blues")
    ax.set_xticks(range(top), names, rotation=60, ha="right"); ax.set_yticks(range(top), names)
    for i in range(top):
        for j in range(top):
            if i != j and M[i, j] >= 10:
                ax.text(j, i, int(M[i, j]), ha="center", va="center", fontsize=7,
                        color="white" if M[i, j] > np.nanmax(M) * 0.55 else INK)
    ax.spines[:].set_visible(False)
    fig.colorbar(im, ax=ax, shrink=0.7, label="Notes sharing both labels")
    ax.set_title("Specialties filed on the same note (top 12)", loc="left", color=INK)
    fig.savefig(C.FIGURES / "fig3_cooccurrence.png"); plt.close(fig)


def main() -> None:
    C.FIGURES.mkdir(parents=True, exist_ok=True)
    raw = load_raw()
    notes = pd.read_pickle(C.DATA_CLEAN)
    labels = json.load(open(C.RESULTS / "data_stats.json"))["final_labels"]
    fig_label_counts(raw, notes, labels)
    fig_note_length(notes)
    fig_cooccurrence(notes, labels)
    print("Saved figures to", C.FIGURES)


if __name__ == "__main__":
    main()
