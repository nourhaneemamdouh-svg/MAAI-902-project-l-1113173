"""
Central configuration for the Clinical Note Routing project.

Every script imports its paths, label taxonomy and random seed from here, so a
single change (e.g. the minimum label support) propagates through the whole
pipeline and the results stay reproducible.
"""
from pathlib import Path

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "Healthcare_Documentation_Database.csv"
DATA_CLEAN = ROOT / "data" / "notes_multilabel.pkl"   # written by data_prep.py
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
MODELS = ROOT / "models"
DEMO = ROOT / "demo"

# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
SEED = 42
N_FOLDS = 5

# --------------------------------------------------------------------------- #
# Label taxonomy
# --------------------------------------------------------------------------- #
# These labels describe the *type of document* (a consult, a letter, a progress
# note) rather than the *clinical specialty* that should receive it. Mixing the
# two turns one classification problem into two, so they are removed as targets.
DOCUMENT_TYPE_LABELS = {
    "Consult - History and Phy.",
    "SOAP / Chart / Progress Notes",
    "Discharge Summary",
    "Office Notes",
    "Letters",
    "Emergency Room Reports",
    "IME-QME-Work Comp etc.",
}

# A specialty must appear in at least this many *unique* notes to be kept as a
# target. Below this, a 5-fold test split would hold 2 or fewer positives and
# per-label F1 becomes noise.
MIN_LABEL_SUPPORT = 15

# Notes shorter than this (in words) carry too little signal to route.
MIN_WORDS = 20

# --------------------------------------------------------------------------- #
# Columns that must NEVER be used as model inputs
# --------------------------------------------------------------------------- #
# `keywords` begins with the specialty name in 100% of rows (direct label
# leakage); `description` and `sample_name` are human-written summaries that a
# routing system would not have at inference time.
LEAKY_COLUMNS = ["keywords", "description", "sample_name", "medical_specialty"]
