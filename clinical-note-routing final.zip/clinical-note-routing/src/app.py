"""
Gradio web UI for the clinical note router.

    pip install gradio
    python src/app.py            # opens http://127.0.0.1:7860

Paste a transcription -> see the assigned specialties, the confidence, whether
the note is auto-routed or sent to human review, the words that drove the
decision and (if scispaCy is installed) the diseases and drugs it mentions.

A dependency-free version of the same model runs in the browser: demo/index.html.
"""
import gradio as gr

from predict import REVIEW_TAU, route

try:  # NER is optional: the app still works without scispaCy
    from ner import extract_entities
    extract_entities("test")
    HAS_NER = True
except Exception:  # noqa: BLE001
    HAS_NER = False


def run(text: str, tau: float):
    if not text or len(text.split()) < 5:
        return {}, "Paste a clinical note (at least a few sentences).", "", ""
    r = route(text, tau=tau)
    decision = (f"**Auto-route to: {', '.join(r['assigned'])}** (confidence {r['confidence']:.0%})"
                if r["decision"] == "auto-route" else
                f"**Send to human review** - top guess {r['top']} at {r['confidence']:.0%} "
                f"is below the {tau:.0%} review threshold.")
    evidence = ", ".join(f"{w}" for w, _ in r["evidence"]) or "-"
    ents = ""
    if HAS_NER:
        e = extract_entities(text)
        ents = (f"**Diseases:** {', '.join(t for t, _ in e['DISEASE']) or '-'}\n\n"
                f"**Drugs:** {', '.join(t for t, _ in e['CHEMICAL']) or '-'}")
    else:
        ents = "_Install scispaCy and en_ner_bc5cdr_md to enable entity extraction._"
    top5 = dict(list(r["probabilities"].items())[:5])
    return top5, decision, f"Words supporting **{r['top']}**: {evidence}", ents


with gr.Blocks(title="Clinical Note Router") as demo:
    gr.Markdown("# Clinical Note Router\nRoutes a medical transcription to the specialties "
                "that should receive it. Research prototype - not for clinical use.")
    with gr.Row():
        with gr.Column(scale=3):
            note = gr.Textbox(lines=14, label="Clinical note")
            tau = gr.Slider(0.3, 0.95, value=REVIEW_TAU, step=0.05,
                            label="Human-review threshold (top-1 confidence)")
            btn = gr.Button("Route note", variant="primary")
        with gr.Column(scale=2):
            probs = gr.Label(label="Top specialties", num_top_classes=5)
            decision = gr.Markdown()
            why = gr.Markdown()
            ents = gr.Markdown()
    btn.click(run, [note, tau], [probs, decision, why, ents])

if __name__ == "__main__":
    demo.launch()
