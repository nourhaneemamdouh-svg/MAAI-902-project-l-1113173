"""
Classical models for multi-label specialty routing, evaluated with 5-fold
iterative-stratified cross-validation on unique notes (leakage-free).

Models
------
M0  Prior            predicts label prevalence (sanity floor)
M1  TF-IDF + NB      one-vs-rest Multinomial Naive Bayes
M2  TF-IDF + SVM     one-vs-rest linear SVM (class-weighted)
M3  TF-IDF + LR      one-vs-rest logistic regression (class-weighted)  <- selected

Decision rule
-------------
Each model outputs a score per specialty. A note receives every specialty whose
score passes a global threshold tuned on an inner validation split (never on
the test fold), and always at least its top-1 specialty, because every note
must be routed somewhere.

Outputs (results/):
  cv_results.json        mean +/- sd of every metric per model
  tuning_results.json    LR hyper-parameter grid
  per_label_f1.csv       out-of-fold F1 per specialty (selected model)
  oof_lr.npz             out-of-fold probabilities for calibration analysis
  figures/fig4..fig6     model comparison, per-label F1, review trade-off
  models/tfidf_lr.joblib final model trained on all notes

Run:  python src/train_baseline.py
"""
from __future__ import annotations

import json
import time

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsRestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

import config as C
from data_prep import to_matrix
from eda import BLUE, GRID, INK, INK2, ORANGE  # shared palette + rcParams

# --------------------------------------------------------------------------- #
# Model factory
# --------------------------------------------------------------------------- #
def tfidf(ngram=(1, 2), max_features=50_000) -> TfidfVectorizer:
    """Word n-gram TF-IDF. sublinear_tf dampens very long notes; min_df=2 drops
    typos and one-off patient details; English stop-words removed."""
    return TfidfVectorizer(ngram_range=ngram, min_df=2, max_df=0.9, sublinear_tf=True,
                           stop_words="english", max_features=max_features)


def make_model(name: str, C_lr: float = 8.0, ngram=(1, 2), max_features=50_000):
    if name == "NB":
        clf = OneVsRestClassifier(MultinomialNB(alpha=0.1))
    elif name == "SVM":
        clf = OneVsRestClassifier(LinearSVC(C=0.5, class_weight="balanced"))
    elif name == "LR":
        clf = OneVsRestClassifier(
            LogisticRegression(C=C_lr, class_weight="balanced", solver="liblinear", max_iter=2000)
        )
    else:
        raise ValueError(name)
    return Pipeline([("tfidf", tfidf(ngram, max_features)), ("clf", clf)])


def scores(model, X) -> np.ndarray:
    """Probability (LR, NB) or margin (SVM) per label."""
    clf = model.named_steps["clf"]
    if hasattr(clf.estimators_[0], "predict_proba"):
        return model.predict_proba(X)
    return model.decision_function(X)


# --------------------------------------------------------------------------- #
# Decision rule and metrics
# --------------------------------------------------------------------------- #
def decide(S: np.ndarray, thr: float) -> np.ndarray:
    """Labels above threshold, plus the top-1 label for every note."""
    P = (S >= thr).astype(int)
    P[np.arange(len(S)), S.argmax(1)] = 1
    return P


def tune_threshold(S: np.ndarray, Y: np.ndarray) -> float:
    """Pick the global threshold that maximises micro-F1 on validation data."""
    lo, hi = np.percentile(S, 50), np.percentile(S, 99.9)
    grid = np.linspace(lo, hi, 60)
    f = [f1_score(Y, decide(S, t), average="micro", zero_division=0) for t in grid]
    return float(grid[int(np.argmax(f))])


def metrics(Y: np.ndarray, S: np.ndarray, P: np.ndarray) -> dict:
    top1 = S.argmax(1)
    return {
        "macro_f1": f1_score(Y, P, average="macro", zero_division=0),
        "micro_f1": f1_score(Y, P, average="micro", zero_division=0),
        "samples_f1": f1_score(Y, P, average="samples", zero_division=0),
        # routing accuracy: is the single best specialty one of the true ones?
        "top1_accuracy": float(Y[np.arange(len(Y)), top1].mean()),
    }


# --------------------------------------------------------------------------- #
# Cross-validation
# --------------------------------------------------------------------------- #
def run_cv(name, notes, Y, **kw):
    """5-fold CV. Inside each training fold, 15% is held out to tune the
    threshold, then the model is refit on the full training fold."""
    rows, oof_S, oof_P = [], np.zeros(Y.shape), np.zeros(Y.shape, dtype=int)
    X = notes["text"].values
    for k in range(C.N_FOLDS):
        tr, te = notes["fold"].values != k, notes["fold"].values == k
        if name == "Prior":
            prev = Y[tr].mean(0)
            S = np.tile(prev, (te.sum(), 1))
            P = decide(S, 1.1)  # top-1 only (always "Surgery")
        else:
            Xtr, Ytr = X[tr], Y[tr]
            a, b = train_test_split(np.arange(len(Xtr)), test_size=0.15, random_state=C.SEED)
            m = make_model(name, **kw).fit(Xtr[a], Ytr[a])
            thr = tune_threshold(scores(m, Xtr[b]), Ytr[b])
            m = make_model(name, **kw).fit(Xtr, Ytr)
            S = scores(m, X[te])
            P = decide(S, thr)
        oof_S[te], oof_P[te] = S, P
        rows.append(metrics(Y[te], S, P))
    df = pd.DataFrame(rows)
    return {m: (round(df[m].mean(), 3), round(df[m].std(), 3)) for m in df}, oof_S, oof_P


def expected_calibration_error(conf, correct, bins=10) -> float:
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any():
            ece += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return float(ece)


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def fig_models(cv: dict) -> None:
    names = list(cv)
    mets = [("macro_f1", "Macro-F1 (primary)"), ("micro_f1", "Micro-F1"), ("top1_accuracy", "Top-1 routing accuracy")]
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.2), sharey=True)
    for ax, (m, title) in zip(axes, mets):
        means = [cv[n][m][0] for n in names]; sds = [cv[n][m][1] for n in names]
        colors = [BLUE if n.startswith("TF-IDF + LR") else "#9db9e0" for n in names]
        ax.barh(range(len(names)), means, xerr=sds, color=colors, height=0.6,
                error_kw={"ecolor": INK2, "capsize": 3, "lw": 1})
        for i, (v, sd) in enumerate(zip(means, sds)):
            ax.text(v + sd + 0.03, i, f"{v:.2f}", va="center", fontsize=8, color=INK)
        ax.set_xlim(0, 1.15); ax.set_title(title, loc="left", fontsize=10, color=INK)
        ax.grid(axis="x", color=GRID); ax.set_axisbelow(True)
    axes[0].set_yticks(range(len(names)), names); axes[0].invert_yaxis()
    fig.suptitle("5-fold cross-validation on 1,751 unique notes (mean ± sd)", x=0.01, ha="left", color=INK)
    fig.tight_layout(); fig.savefig(C.FIGURES / "fig4_model_comparison.png"); plt.close(fig)


def fig_per_label(per_label: pd.DataFrame) -> None:
    d = per_label.sort_values("f1")
    fig, ax = plt.subplots(figsize=(7.5, 6.6))
    ax.barh(range(len(d)), d["f1"], color=BLUE, height=0.7)
    for i, (f, n) in enumerate(zip(d["f1"], d["support"])):
        ax.text(f + 0.01, i, f"{f:.2f}  (n={n})", va="center", fontsize=8, color=INK2)
    ax.set_yticks(range(len(d)), d.index); ax.set_xlim(0, 1.1)
    ax.set_xlabel("Out-of-fold F1"); ax.grid(axis="x", color=GRID); ax.set_axisbelow(True)
    ax.set_title("F1 per specialty, TF-IDF + logistic regression", loc="left", color=INK)
    fig.savefig(C.FIGURES / "fig5_per_label_f1.png"); plt.close(fig)


def fig_review(conf, correct) -> pd.DataFrame:
    """Selective prediction: auto-route notes whose top-1 confidence >= tau,
    send the rest to a human. Plot accuracy on the automated share."""
    taus = np.round(np.arange(0.0, 0.96, 0.05), 2)
    rows = [{"tau": t, "coverage": (conf >= t).mean(),
             "accuracy": correct[conf >= t].mean() if (conf >= t).any() else np.nan} for t in taus]
    d = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    ax.plot(d["coverage"] * 100, d["accuracy"] * 100, color=BLUE, lw=2, marker="o", ms=5)
    for _, r in d[d["tau"].isin([0.0, 0.5, 0.7, 0.9])].iterrows():
        ax.annotate(f"τ={r.tau:.1f}", (r.coverage * 100, r.accuracy * 100), textcoords="offset points",
                    xytext=(6, -12), fontsize=8, color=INK2)
    ax.set_xlabel("Notes routed automatically (%)"); ax.set_ylabel("Top-1 accuracy on those (%)")
    ax.invert_xaxis(); ax.grid(color=GRID); ax.set_axisbelow(True)
    ax.set_title("Human-review trade-off: fewer automated notes, higher accuracy", loc="left", color=INK)
    fig.savefig(C.FIGURES / "fig6_review_tradeoff.png"); plt.close(fig)
    return d


# --------------------------------------------------------------------------- #
def main() -> None:
    notes = pd.read_pickle(C.DATA_CLEAN)
    stats = json.load(open(C.RESULTS / "data_stats.json"))
    labels = stats["final_labels"]
    Y = to_matrix(notes, labels)

    # ---- 1. hyper-parameter tuning for LR (CV macro-F1) ------------------- #
    tuning = []
    for ngram in [(1, 1), (1, 2)]:
        for c in [1.0, 4.0, 16.0, 32.0, 64.0]:
            t0 = time.time()
            res, _, _ = run_cv("LR", notes, Y, C_lr=c, ngram=ngram)
            tuning.append({"ngram": f"{ngram[0]}-{ngram[1]}", "C": c,
                           "macro_f1": res["macro_f1"][0], "micro_f1": res["micro_f1"][0],
                           "top1_accuracy": res["top1_accuracy"][0], "secs": round(time.time() - t0, 1)})
            print("tuning", tuning[-1])
    tuning = pd.DataFrame(tuning)
    best = tuning.sort_values("macro_f1", ascending=False).iloc[0]
    best_ngram = tuple(int(x) for x in best["ngram"].split("-"))
    best_C = float(best["C"])
    tuning.to_json(C.RESULTS / "tuning_results.json", orient="records", indent=2)

    # ---- 2. model comparison --------------------------------------------- #
    cv, oof = {}, {}
    for disp, name in [("Prior (always Surgery)", "Prior"), ("TF-IDF + Naive Bayes", "NB"),
                       ("TF-IDF + Linear SVM", "SVM"), ("TF-IDF + LR (tuned)", "LR")]:
        kw = {"C_lr": best_C, "ngram": best_ngram} if name == "LR" else {}
        res, S, P = run_cv(name, notes, Y, **kw)
        cv[disp] = res; oof[name] = (S, P)
        print(disp, res)
    json.dump({"models": cv, "best_lr": {"C": best_C, "ngram": best["ngram"]}},
              open(C.RESULTS / "cv_results.json", "w"), indent=2)
    fig_models(cv)

    # ---- 3. per-label analysis, calibration, human review ----------------- #
    S, P = oof["LR"]
    per_label = pd.DataFrame({
        "f1": f1_score(Y, P, average=None, zero_division=0).round(3),
        "support": Y.sum(0)}, index=labels)
    per_label.to_csv(C.RESULTS / "per_label_f1.csv")
    fig_per_label(per_label)

    conf = S.max(1); correct = Y[np.arange(len(Y)), S.argmax(1)].astype(float)
    ece = expected_calibration_error(conf, correct)
    review = fig_review(conf, correct)
    review.to_csv(C.RESULTS / "review_tradeoff.csv", index=False)
    np.savez(C.RESULTS / "oof_lr.npz", S=S, P=P, Y=Y)
    json.dump({"top1_ece": round(ece, 3)}, open(C.RESULTS / "calibration.json", "w"))
    print("ECE (top-1):", round(ece, 3))

    # ---- 4. final model on all notes ------------------------------------- #
    train_final(notes, Y, labels, best_C, best_ngram)


def train_final(notes, Y, labels, C_lr=64.0, ngram=(1, 1)) -> dict:
    """Fit the selected model on every note, tune its threshold on a 15%
    hold-out, save it with the scikit-learn version it was built with, and
    return the bundle. predict.load() calls this if the saved file was made
    with a different scikit-learn version (e.g. on Google Colab)."""
    import sklearn
    a, b = train_test_split(np.arange(len(notes)), test_size=0.15, random_state=C.SEED)
    X = notes["text"].values
    thr = tune_threshold(scores(make_model("LR", C_lr, ngram).fit(X[a], Y[a]), X[b]), Y[b])
    final = make_model("LR", C_lr, ngram).fit(X, Y)
    bundle = {"model": final, "labels": labels, "threshold": thr, "sklearn": sklearn.__version__}
    C.MODELS.mkdir(exist_ok=True)
    joblib.dump(bundle, C.MODELS / "tfidf_lr.joblib")
    print("Saved final model, threshold =", round(thr, 3))
    return bundle

if __name__ == "__main__":
    main()
