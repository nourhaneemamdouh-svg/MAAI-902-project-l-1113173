"""
Ablation: how much do evaluation choices change the headline score?

Published MTSamples results range from macro-F1 ~0.28 to accuracy ~0.99. This
script reproduces the common protocols with ONE fixed model (TF-IDF + logistic
regression) so that differences come only from the protocol, not the model.

Single-label protocols (as in most prior work: one row = one label, 38-39 classes)
  E0  raw rows, random stratified split, no oversampling
  E1  raw rows, oversample minority classes BEFORE the split    (leaky)
  E2  raw rows, oversample AFTER the split (train only)
  E3  E2 + the `keywords` column appended to the text             (leaky)
  E4  raw rows, split grouped by transcription (no shared text)

Multi-label protocols (unique notes, 5-fold iterative stratification)
  E5  all specialty + document-type labels with >= 3 notes  (no taxonomy fix)
  E6  24 cleaned specialty labels                           (this project)

Run:  python src/leakage_experiments.py
"""
import json

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.pipeline import Pipeline

import config as C
from data_prep import build_dataset, clean_text, iterative_stratified_folds, load_raw, to_matrix
from train_baseline import run_cv

RNG = np.random.default_rng(C.SEED)


def single_label_model():
    return Pipeline([
        ("tfidf", TfidfVectorizer(min_df=2, max_df=0.9, sublinear_tf=True, stop_words="english")),
        ("clf", LogisticRegression(C=16, max_iter=3000)),
    ])


def oversample(X, y):
    """Random oversampling: duplicate minority-class rows until every class
    matches the largest one (the text-level analogue of SMOTE)."""
    X, y = np.asarray(X), np.asarray(y)
    n_max = pd.Series(y).value_counts().max()
    idx = []
    for c in np.unique(y):
        rows = np.where(y == c)[0]
        idx.extend(rows); idx.extend(RNG.choice(rows, n_max - len(rows), replace=True))
    idx = np.array(idx)
    return X[idx], y[idx]


def score_single(ytrue, ypred):
    return {"accuracy": round(accuracy_score(ytrue, ypred), 3),
            "weighted_f1": round(f1_score(ytrue, ypred, average="weighted"), 3),
            "macro_f1": round(f1_score(ytrue, ypred, average="macro"), 3)}


def main():
    raw = load_raw()
    raw["text"] = raw["transcription"].map(clean_text)
    raw = raw[raw["text"].str.split().map(len) >= C.MIN_WORDS].reset_index(drop=True)
    y = raw["medical_specialty"].values
    out = {}

    # E0: plain random stratified split, no oversampling (the "naive" protocol)
    a, b = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=C.SEED)
    m = single_label_model().fit(raw["text"].values[a], y[a])
    out["E0 random split, no oversampling"] = score_single(y[b], m.predict(raw["text"].values[b]))

    # E1: oversample, then split (synthetic copies of a test note sit in training)
    Xo, yo = oversample(raw["text"].values, y)
    a, b = train_test_split(np.arange(len(yo)), test_size=0.2, stratify=yo, random_state=C.SEED)
    m = single_label_model().fit(Xo[a], yo[a])
    out["E1 oversample before split"] = score_single(yo[b], m.predict(Xo[b]))

    # E2: split, then oversample the training part only
    a, b = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=C.SEED)
    Xa, ya = oversample(raw["text"].values[a], y[a])
    m = single_label_model().fit(Xa, ya)
    out["E2 oversample after split"] = score_single(y[b], m.predict(raw["text"].values[b]))

    # E3: E2 + keywords column (it begins with the label name)
    text_kw = (raw["keywords"].fillna("").map(clean_text) + " " + raw["text"]).values
    Xa, ya = oversample(text_kw[a], y[a])
    m = single_label_model().fit(Xa, ya)
    out["E3 + keywords column"] = score_single(y[b], m.predict(text_kw[b]))

    # E4: grouped split, so no transcription appears on both sides
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=C.SEED)
    a, b = next(gss.split(raw, y, groups=raw["text"]))
    m = single_label_model().fit(raw["text"].values[a], y[a])
    out["E4 grouped split (no shared text)"] = score_single(y[b], m.predict(raw["text"].values[b]))

    # E5: multi-label, unique notes, no taxonomy fix (keep every label with >= 3 notes)
    import config
    saved = (config.DOCUMENT_TYPE_LABELS, config.MIN_LABEL_SUPPORT)
    config.DOCUMENT_TYPE_LABELS, config.MIN_LABEL_SUPPORT = set(), 3
    notes5, st5 = build_dataset(load_raw())
    config.DOCUMENT_TYPE_LABELS, config.MIN_LABEL_SUPPORT = saved
    Y5 = to_matrix(notes5, st5["final_labels"])
    notes5["fold"] = iterative_stratified_folds(Y5, C.N_FOLDS, C.SEED)
    res5, _, _ = run_cv("LR", notes5, Y5, C_lr=64.0, ngram=(1, 1))
    out[f"E5 multi-label, all {st5['n_final_labels']} labels"] = {k: v[0] for k, v in res5.items()}

    # E6: this project's setting
    notes6 = pd.read_pickle(C.DATA_CLEAN)
    lab6 = json.load(open(C.RESULTS / "data_stats.json"))["final_labels"]
    res6, _, _ = run_cv("LR", notes6, to_matrix(notes6, lab6), C_lr=64.0, ngram=(1, 1))
    out["E6 multi-label, 24 cleaned labels"] = {k: v[0] for k, v in res6.items()}

    for k, v in out.items():
        print(f"{k:42s} {v}")
    json.dump({k: {m: float(x) for m, x in v.items()} for k, v in out.items()},
              open(C.RESULTS / "leakage_experiments.json", "w"), indent=2)


if __name__ == "__main__":
    main()
