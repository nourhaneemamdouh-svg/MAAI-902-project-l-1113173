"""
Inference helpers shared by the Gradio app, the notebook and the demo export.

route(text) returns everything a routing user needs:
  * a probability for every specialty
  * the specialties assigned (threshold rule, always >= 1)
  * whether the note can be auto-routed or needs human review
  * the words that pushed the top specialty up (explanation)
"""
from __future__ import annotations

from functools import lru_cache

import joblib
import numpy as np

import config as C
from data_prep import clean_text

REVIEW_TAU = 0.70  # top-1 confidence below this -> human review (see fig6)


@lru_cache(maxsize=1)
def load():
    """Load the saved model. A joblib file only loads reliably with the
    scikit-learn version that wrote it, so if the versions differ (or the
    file is missing) the model is retrained from the CSV in about 15 s."""
    import sklearn
    path = C.MODELS / "tfidf_lr.joblib"
    try:
        bundle = joblib.load(path)
        if bundle.get("sklearn") == sklearn.__version__:
            return bundle
        print(f"Saved model was built with scikit-learn {bundle.get('sklearn')}; "
              f"this environment has {sklearn.__version__}. Retraining...")
    except Exception as e:  # noqa: BLE001  (missing file, unpickling error)
        print(f"Could not load the saved model ({type(e).__name__}). Retraining...")
    import json
    from data_prep import build_dataset, load_raw, to_matrix
    from train_baseline import train_final
    notes, stats = build_dataset(load_raw())
    best = json.load(open(C.RESULTS / "cv_results.json"))["best_lr"]
    ngram = tuple(int(x) for x in best["ngram"].split("-"))
    return train_final(notes, to_matrix(notes, stats["final_labels"]), stats["final_labels"], best["C"], ngram)


def route(text: str, tau: float = REVIEW_TAU, n_terms: int = 8) -> dict:
    bundle = load()
    model, labels, thr = bundle["model"], bundle["labels"], bundle["threshold"]
    clean = clean_text(text)
    x = model.named_steps["tfidf"].transform([clean])
    probs = np.array([est.predict_proba(x)[0, 1] for est in model.named_steps["clf"].estimators_])

    order = np.argsort(-probs)
    assigned = [labels[i] for i in order if probs[i] >= thr] or [labels[order[0]]]
    if labels[order[0]] not in assigned:
        assigned.insert(0, labels[order[0]])

    # Explanation: contribution of each word = tf-idf value x coefficient
    top = order[0]
    w = model.named_steps["clf"].estimators_[top].coef_[0]
    vocab = model.named_steps["tfidf"].get_feature_names_out()
    contrib = x.toarray()[0] * w
    idx = [i for i in np.argsort(-contrib)[:n_terms] if contrib[i] > 0]

    return {
        "probabilities": {labels[i]: float(probs[i]) for i in order},
        "assigned": assigned,
        "top": labels[top],
        "confidence": float(probs[top]),
        "decision": "auto-route" if probs[top] >= tau else "human review",
        "evidence": [(vocab[i], float(contrib[i])) for i in idx],
    }


if __name__ == "__main__":
    demo = ("PROCEDURE: Left knee arthroscopy with partial medial meniscectomy. "
            "ANESTHESIA: General. The tourniquet was inflated and the joint was inspected.")
    import json
    print(json.dumps(route(demo), indent=2)[:1200])
